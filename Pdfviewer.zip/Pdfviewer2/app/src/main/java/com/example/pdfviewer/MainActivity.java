package com.example.pdfviewer;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.Intent;


import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button btnPrev, btnNext, btnPick;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page currentPage;
    private ParcelFileDescriptor parcelFileDescriptor;
    private int totalPages = 0;
    private int currentPageIndex = 0;

    private ActivityResultLauncher<String[]> openDocumentLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnPick = findViewById(R.id.btnPick);

        // Register OpenDocument launcher
        openDocumentLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri != null) {
                            try {
                                getContentResolver().takePersistableUriPermission(uri,
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            } catch (Exception e) {
                                // Ignore
                            }
                            openRenderer(uri);
                            showPage(0);
                        }
                    }
                }
        );

        btnPick.setOnClickListener(v -> {
            openDocumentLauncher.launch(new String[]{"application/pdf"});
        });

        btnPrev.setOnClickListener(v -> {
            if (pdfRenderer != null && currentPageIndex > 0) {
                showPage(currentPageIndex - 1);
            }
        });

        btnNext.setOnClickListener(v -> {
            if (pdfRenderer != null && currentPageIndex < totalPages - 1) {
                showPage(currentPageIndex + 1);
            }
        });
    }

    private void openRenderer(Uri uri) {
        try {
            closeRenderer(); // Close if already open
            parcelFileDescriptor = getContentResolver().openFileDescriptor(uri, "r");
            if (parcelFileDescriptor != null) {
                pdfRenderer = new PdfRenderer(parcelFileDescriptor);
                totalPages = pdfRenderer.getPageCount();
                Toast.makeText(this, "Total Pages: " + totalPages, Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error opening PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private void showPage(int index) {
        if (pdfRenderer == null || index < 0 || index >= totalPages) return;

        if (currentPage != null) currentPage.close();

        currentPage = pdfRenderer.openPage(index);
        Bitmap bitmap = Bitmap.createBitmap(
                currentPage.getWidth() * 2, // Scale for clarity
                currentPage.getHeight() * 2,
                Bitmap.Config.ARGB_8888
        );
        currentPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageBitmap(bitmap);

        currentPageIndex = index;
        updateButtonState();
    }

    private void updateButtonState() {
        btnPrev.setEnabled(currentPageIndex > 0);
        btnNext.setEnabled(currentPageIndex < totalPages - 1);
    }

    private void closeRenderer() {
        try {
            if (currentPage != null) currentPage.close();
            if (pdfRenderer != null) pdfRenderer.close();
            if (parcelFileDescriptor != null) parcelFileDescriptor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeRenderer();
    }
}
